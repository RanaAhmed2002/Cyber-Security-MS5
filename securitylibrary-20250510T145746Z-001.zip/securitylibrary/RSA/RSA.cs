﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;




namespace SecurityLibrary.RSA
{
    public class RSA
    {
        public int Encrypt(int p, int q, int M, int e)
        {
            if (!IsPrime(p) || !IsPrime(q))
                return -1;

            int n = p * q;
            int phi = (p - 1) * (q - 1);

            if (Gcd(e, phi) != 1)
                return -1;

            BigInteger bigM = new BigInteger(M);
            BigInteger bigE = new BigInteger(e);
            BigInteger bigN = new BigInteger(n);
            BigInteger cipherText = BigInteger.ModPow(bigM, bigE, bigN);

            return (int)cipherText;
        }

        public int Decrypt(int p, int q, int C, int e)
        {
            if (!IsPrime(p) || !IsPrime(q))
                return -1;

            int n = p * q;
            int phi = (p - 1) * (q - 1);
            int d = ModularInverse(e, phi);

            if (d == -1)
                return -1;

            BigInteger bigC = new BigInteger(C);
            BigInteger bigD = new BigInteger(d);
            BigInteger bigN = new BigInteger(n);
            BigInteger plainText = BigInteger.ModPow(bigC, bigD, bigN);

            return (int)plainText;
        }

        private int ModularInverse(int a, int m)
        {
            int m0 = m, t, q;
            int x0 = 0, x1 = 1;

            if (m == 1) return -1;

            while (a > 1)
            {
                q = a / m;
                t = m;
                m = a % m;
                a = t;
                t = x0;
                x0 = x1 - q * x0;
                x1 = t;
            }

            return x1 < 0 ? x1 + m0 : x1;
        }

        private bool IsPrime(int num)
        {
            if (num <= 1) return false;
            if (num <= 3) return true;

            if (num % 2 == 0 || num % 3 == 0) return false;

            for (int i = 5; i * i <= num; i += 6)
            {
                if (num % i == 0 || num % (i + 2) == 0)
                    return false;
            }
            return true;
        }

        private int Gcd(int a, int b)
        {
            while (b != 0)
            {
                int t = b;
                b = a % b;
                a = t;
            }
            return a;
        }
    }
}

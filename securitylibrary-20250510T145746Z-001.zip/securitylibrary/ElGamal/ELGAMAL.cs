﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary.ElGamal
{
    public class ElGamal
    {
        /// <summary>
        /// Encryption
        /// </summary>
        /// <param name="alpha"></param>
        /// <param name="q"></param>
        /// <param name="y"></param>
        /// <param name="k"></param>
        /// <returns>list[0] = C1, List[1] = C2</returns>
        /// 

        public static int Pow(int b, int e, int m)
        {
            int result = 1;

            while (e > 0)
            {
                if ((e & 1) == 1)
                {
                    long x = (long)result;
                    long y = (long)b;
                    long res = x * y;

                    res %= m;
                    result = (int)(res);
                }

                long z = (long)b;
                long f = (long)b;
                long res2 = z * f;

                res2 %= m;
                b = (int)(res2);
                e /= 2;
            }

            return result;
        }

        public List<long> Encrypt(int q, int alpha, int y, int k, int m)
        {

            int x = Pow(y, k, q);
            long key1 = (long)Pow(alpha, k, q);
            long key2 = ((long)x * (long)m) % q;

            List<long> result = new List<long>();
            result.Add(key1);
            result.Add(key2);

            return result;
        }

        public int Decrypt(int c1, int c2, int x, int q)
        {


            int secret_key = 1;

            for (int i = 0; i < x; i++)
                secret_key = (secret_key * c1) % q;

            int m = Pow(secret_key, q - 2, q);
            int result = (c2 * m) % q;

            return result;

        }
    }
}

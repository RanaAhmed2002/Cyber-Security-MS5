﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;


namespace SecurityLibrary.DiffieHellman
{


    public class DiffieHellman
    {

        public int power(int f, int s, int sf)
        {
            int result = 1;
            while (s > 0)
            {
                if (s % 2 == 1)
                {
                    result = (result * f) % sf;
                }
                f = (f * f) % sf;
                s /= 2;
            }
            return result;
        }

        public List<int> GetKeys(int q, int alpha, int xa, int xb)
        {
            List<int> result = new List<int>();

            int ya = power(alpha, xa, q);
            int yb = power(alpha, xb, q);

            // Calculate shared secret key
            int xkey = power(yb, xa, q);
            int ykey = power(ya, xb, q);

            result.Add(xkey);
            result.Add(ykey);

            return result;
        }
    }
}
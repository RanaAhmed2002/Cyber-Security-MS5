﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary.AES
{
    public class ExtendedEuclid
    {
        public int GetMultiplicativeInverse(int number, int baseN)
        {
            int[] result = ExtendedEuclideanAlgorithm(number, baseN);
            if (result[0] != 1)
            {
                return -1;
                //throw new Exception("Inverse does not exist.");
            }
            int inverse = result[1];
            // Ensure the result is positive
            return (inverse % baseN + baseN) % baseN;
        }

        private int[] ExtendedEuclideanAlgorithm(int a, int b)
        {
            int x = 0, y = 1, lastx = 1, lasty = 0;
            while (b != 0)
            {
                int quotient = a / b;
                int temp = a;
                a = b;
                b = temp % b;

                temp = x;
                x = lastx - quotient * x;
                lastx = temp;

                temp = y;
                y = lasty - quotient * y;
                lasty = temp;
            }
            return new int[] { a, lastx, lasty };
        }
    }
}

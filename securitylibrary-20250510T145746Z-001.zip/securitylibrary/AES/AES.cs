﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary.AES
{
    /// <summary>
    /// If the string starts with 0x.... then it's Hexadecimal not string
    /// </summary>
    public class AES : CryptographicTechnique
    {
        public static string[] SBOX = {
            "63", "7C", "77", "7B", "F2", "6B", "6F", "C5", "30", "01", "67", "2B", "FE", "D7", "AB", "76",
            "CA", "82", "C9", "7D", "FA", "59", "47", "F0", "AD", "D4", "A2", "AF", "9C", "A4", "72", "C0",
            "B7", "FD", "93", "26", "36", "3F", "F7", "CC", "34", "A5", "E5", "F1", "71", "D8", "31", "15",
            "04", "C7", "23", "C3", "18", "96", "05", "9A", "07", "12", "80", "E2", "EB", "27", "B2", "75",
            "09", "83", "2C", "1A", "1B", "6E", "5A", "A0", "52", "3B", "D6", "B3", "29", "E3", "2F", "84",
            "53", "D1", "00", "ED", "20", "FC", "B1", "5B", "6A", "CB", "BE", "39", "4A", "4C", "58", "CF",
            "D0", "EF", "AA", "FB", "43", "4D", "33", "85", "45", "F9", "02", "7F", "50", "3C", "9F", "A8",
            "51", "A3", "40", "8F", "92", "9D", "38", "F5", "BC", "B6", "DA", "21", "10", "FF", "F3", "D2",
            "CD", "0C", "13", "EC", "5F", "97", "44", "17", "C4", "A7", "7E", "3D", "64", "5D", "19", "73",
            "60", "81", "4F", "DC", "22", "2A", "90", "88", "46", "EE", "B8", "14", "DE", "5E", "0B", "DB",
            "E0", "32", "3A", "0A", "49", "06", "24", "5C", "C2", "D3", "AC", "62", "91", "95", "E4", "79",
            "E7", "C8", "37", "6D", "8D", "D5", "4E", "A9", "6C", "56", "F4", "EA", "65", "7A", "AE", "08",
            "BA", "78", "25", "2E", "1C", "A6", "B4", "C6", "E8", "DD", "74", "1F", "4B", "BD", "8B", "8A",
            "70", "3E", "B5", "66", "48", "03", "F6", "0E", "61", "35", "57", "B9", "86", "C1", "1D", "9E",
            "E1", "F8", "98", "11", "69", "D9", "8E", "94", "9B", "1E", "87", "E9", "CE", "55", "28", "DF",
            "8C", "A1", "89", "0D", "BF", "E6", "42", "68", "41", "99", "2D", "0F", "B0", "54", "BB", "16"
        };
        public static string[] mixCols = {
        "02", "03", "01", "01",
        "01", "02", "03", "01",
        "01", "01", "02", "03",
        "03", "01", "01", "02"
        };
        public static string[,] Rcon =
       {
             { "01" , "02" , "04" , "08" , "10", "20"  , "40" , "80" , "1b" , "36" },
           { "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" } ,
           { "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" } ,
           { "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" }
        };
        public static string[,] S_box ={
            {"63","7c","77","7b","f2","6b","6f","c5","30","01","67","2b","fe","d7","ab","76"},
            {"ca","82","c9","7d","fa","59","47","f0","ad","d4","a2","af","9c","a4","72","c0"},
            {"b7","fd","93","26","36","3f","f7","cc","34","a5","e5","f1","71","d8","31","15"},
            {"04","c7","23","c3","18","96","05","9a","07","12","80","e2","eb","27","b2","75"},
            {"09","83","2c","1a","1b","6e","5a","a0","52","3b","d6","b3","29","e3","2f","84"},
            {"53","d1","00","ed","20","fc","b1","5b","6a","cb","be","39","4a","4c","58","cf"},
            {"d0","ef","aa","fb","43","4d","33","85","45","f9","02","7f","50","3c","9f","a8"},
            {"51","a3","40","8f","92","9d","38","f5","bc","b6","da","21","10","ff","f3","d2"},
            {"cd","0c","13","ec","5f","97","44","17","c4","a7","7e","3d","64","5d","19","73"},
            {"60","81","4f","dc","22","2a","90","88","46","ee","b8","14","de","5e","0b","db"},
            {"e0","32","3a","0a","49","06","24","5c","c2","d3","ac","62","91","95","e4","79"},
            {"e7","c8","37","6d","8d","d5","4e","a9","6c","56","f4","ea","65","7a","ae","08"},
            {"ba","78","25","2e","1c","a6","b4","c6","e8","dd","74","1f","4b","bd","8b","8a"},
            {"70","3e","b5","66","48","03","f6","0e","61","35","57","b9","86","c1","1d","9e"},
            {"e1","f8","98","11","69","d9","8e","94","9b","1e","87","e9","ce","55","28","df"},
            {"8c","a1","89","0d","bf","e6","42","68","41","99","2d","0f","b0","54","bb","16"}
            };
        public static string[,] R_con =
       {
                { "01" , "02" , "04" , "08" , "10" , "20" , "40" , "80" , "1b" , "36"},
                { "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" },
                { "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" },
                { "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" , "00" }



            };
        public static string get_sub_bytes_string(string x)
        {
            string y = "0x" + x;
            x = y;
            string newbytes = "";

            x = x.ToUpper();
            if (x.Length == 8)
            {
                int counter = 0;
                while (counter < 7)
                {
                    int row = (int)x[counter] - '0';
                    if (row > 9)
                        row = row - 7;
                    counter++;
                    int col = (int)x[counter] - '0';
                    if (col > 9)
                        col = col - 7;
                    newbytes = newbytes + SBOX[16 * row + col];
                    counter++;
                }
            }
            else
            {

                int counter = 0;
                while (counter < 31)
                {
                    int row = (int)x[counter + 2] - '0';
                    if (row > 9)
                        row = row - 7;
                    counter++;
                    int col = (int)x[counter + 2] - '0';
                    if (col > 9)
                        col = col - 7;
                    newbytes = newbytes + SBOX[16 * row + col];
                    counter++;
                }
            }
            return newbytes;

        }
        public static string shift_rows(string x)
        {
            string shifted_one = "";
            string first_row = "";
            for (int i = 0; i < 8; i++)
                first_row = first_row + x[i];

            string second_row = "";
            for (int i = 0; i < 6; i++)
                second_row = second_row + x[8 + 2 + i];
            for (int i = 0; i < 2; i++)
                second_row = second_row + x[8 + i];

            string third_row = "";
            for (int i = 0; i < 4; i++)
                third_row = third_row + x[20 + i];
            for (int i = 0; i < 4; i++)
                third_row = third_row + x[16 + i];

            string fourth_row = "";
            for (int i = 0; i < 2; i++)
                fourth_row = fourth_row + x[23 + 7 + i];
            for (int i = 0; i < 6; i++)
                fourth_row = fourth_row + x[24 + i];

            shifted_one = shifted_one + first_row;
            shifted_one = shifted_one + second_row;
            shifted_one = shifted_one + third_row;
            shifted_one = shifted_one + fourth_row;
            return shifted_one;

        }
        public static string matrix_transpose(string matrix)
        {
            int[] arr = { 0, 1, 8, 9, 16, 17, 24, 25, 2, 3, 10, 11, 18, 19, 26, 27, 4, 5, 12, 13, 20, 21, 28, 29, 6, 7, 14, 15, 22, 23, 30, 31 };
            string trans = "";
            for (int i = 0; i < 32; i++)
                trans = trans + matrix[arr[i]];
            string y = trans;
            return trans;
        }
        public static string hextodec(string value)
        {

            int decValue = int.Parse(value, System.Globalization.NumberStyles.HexNumber);
            string num = decValue.ToString();
            return num;
        }
        public static string DecimalToHexadecimal(int dec)
        {
            if (dec < 1) return "0";

            int hex = dec;
            string hexStr = string.Empty;

            while (dec > 0)
            {
                hex = dec % 16;

                if (hex < 10)
                    hexStr = hexStr.Insert(0, Convert.ToChar(hex + 48).ToString());
                else
                    hexStr = hexStr.Insert(0, Convert.ToChar(hex + 55).ToString());

                dec /= 16;

            }

            return hexStr;
        }
        public static string convert_from_hexa_binary(string matrix)
        {
            matrix = matrix.ToUpper();
            int count = 0;
            string hexNum = matrix;
            string retuner = "";
            while (count != 2)
            {
                switch (hexNum[count])
                {
                    case '0':
                        retuner += "0000";
                        break;
                    case '1':
                        retuner += "0001";
                        break;
                    case '2':
                        retuner += "0010";
                        break;
                    case '3':
                        retuner += "0011";
                        break;
                    case '4':
                        retuner += "0100";
                        break;
                    case '5':
                        retuner += "0101";
                        break;
                    case '6':
                        retuner += "0110";
                        break;
                    case '7':
                        retuner += "0111";
                        break;
                    case '8':
                        retuner += "1000";
                        break;
                    case '9':
                        retuner += "1001";
                        break;
                    case 'A':
                        retuner += "1010";
                        break;
                    case 'B':
                        retuner += "1011";
                        break;
                    case 'C':
                        retuner += "1100";
                        break;
                    case 'D':
                        retuner += "1101";
                        break;
                    case 'E':
                        retuner += "1110";
                        break;
                    case 'F':
                        retuner += "1111";
                        break;

                }
                count++;
            }
            return retuner;
        }
        public static string x_or(string first, string second)
        {

            string returner = "";
            for (int i = 0; i < first.Length; i++)
            {
                if (first[i] == second[i])
                    returner += "0";
                else
                    returner += "1";
            }

            return returner;
        }
        public static string dot_mul(string mixcols, string matrix)
        {
            if (mixcols == "01")
                return convert_from_hexa_binary(matrix);
            else if (mixcols == "02")
            {
                string converter = convert_from_hexa_binary(matrix);
                string shifter = "";
                for (int i = 0; i < converter.Length - 1; i++)
                {
                    shifter += converter[i + 1];

                }
                shifter += "0";
                string xoring = x_or(shifter, "00011011");
                return xoring;
            }
            else
            {
                string converter = convert_from_hexa_binary(matrix);
                string shifter = "";
                for (int i = 0; i < converter.Length - 1; i++)
                {
                    shifter += converter[i + 1];

                }
                shifter += "0";
                //      string xoring = x_or(shifter, "00011011");
                string xoring = x_or(shifter, converter);
                return xoring;
            }

        }

        public static string convert_from_binary_to_hex_helper(string x)
        {
            if (x == "0000")
                return "0";
            else if (x == "0001")
                return "1";
            else if (x == "0010")
                return "2";
            else if (x == "0011")
                return "3";
            else if (x == "0100")
                return "4";
            else if (x == "0101")
                return "5";
            else if (x == "0110")
                return "6";
            else if (x == "0111")
                return "7";
            else if (x == "1000")
                return "8";
            else if (x == "1001")
                return "9";
            else if (x == "1010")
                return "A";
            else if (x == "1011")
                return "B";
            else if (x == "1100")
                return "C";
            else if (x == "1011")
                return "D";
            else if (x == "1110")
                return "E";
            else if (x == "1111")
                return "F";
            else
                return "-";
        }
        public static string convert_from_hexa_binary_32bit(string x)
        {
            string returner = "";
            int counter = 0;
            string goer = "";
            for (int i = 0; i < 4; i++)
            {
                goer = "";
                goer += x[counter];
                counter++;
                goer += x[counter];
                counter++;
                returner += convert_from_hexa_binary(goer);
            }
            return returner;
        }
        public static string convert_from_binary_to_hex(string x)
        {
            x = x.ToUpper();
            string first_half = "";
            for (int i = 0; i < 4; i++)
                first_half += x[i];
            string second_half = "";
            for (int i = 4; i < 8; i++)
                second_half += x[i];
            string returner = "";
            returner += convert_from_binary_to_hex_helper(first_half);
            returner += convert_from_binary_to_hex_helper(second_half);
            return returner;
        }
        public static string convert_from_binary_to_hex_32bit(string x)
        {
            int counter = 0;
            string egaba = "";
            for (int i = 0; i < 4; i++)
            {
                string goer = "";
                for (int j = 0; j < 8; j++)
                    goer += x[counter++];
                egaba += convert_from_binary_to_hex(goer);
            }
            return egaba;
        }


        public string mix_cols(string x)
        {

            string[,] parser = new string[4, 4];
            x = matrix_transpose(x);
            int c = 0;
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                {
                    string l = x[c].ToString() + x[c + 1].ToString();
                    parser[i, j] = int.Parse(hextodec(x[c].ToString() + x[c + 1].ToString())).ToString().ToString();
                    c = c + 2;
                }

            int[,] multlication = new int[4, 4];

            for (c = 0; c < 4; c++)
            {

                multlication[0, c] = (Dot_muls("02", parser[0, c]) ^ Dot_muls("03", parser[1, c]) ^
                                          Dot_muls("01", parser[2, c]) ^ Dot_muls("01", parser[3, c]));

                multlication[1, c] = (Dot_muls("01", parser[0, c]) ^ Dot_muls("02", parser[1, c]) ^
                                         Dot_muls("03", parser[2, c]) ^ Dot_muls("01", parser[3, c]));

                multlication[2, c] = (Dot_muls("01", parser[0, c]) ^ (Dot_muls("01", parser[1, c]) ^
                                           Dot_muls("02", parser[2, c]) ^ Dot_muls("03", parser[3, c])));

                multlication[3, c] = (Dot_muls("03", parser[0, c]) ^ Dot_muls("01", parser[1, c]) ^
                                           Dot_muls("01", parser[2, c]) ^ Dot_muls("02", parser[3, c]));

            }

            string[,] converter = new string[4, 4];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    converter[i, j] = DecimalToHexadecimal(multlication[i, j]);
                }

            }

            converter = checker(converter);
            string returner = "";
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    returner += converter[j, i];
                }
            }
            return returner;

        }
        public static string[,] checker(string[,] checkerr)
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (checkerr[i, j].Length < 2)
                    {
                        checkerr[i, j] = "0" + checkerr[i, j];
                    }
                }
            }
            return checkerr;
        }
        public static int Dot_muls(string which_mul, string integ)
        {
            int b = int.Parse(integ);

            if (which_mul == "01")
                return b;
            else if (which_mul == "02")
            {

                b = b << 1;
                if ((b & 256) != 0)
                {
                    b -= 256;
                    b ^= 27;
                }
                return b;

            }
            else
            {
                int y = b;
                b = b << 1;
                if ((b & 256) != 0)
                {
                    b -= 256;
                    b ^= 27;
                }
                return b ^ y;

            }
        }
        static string KeyExpansion(string key, int round)
        {
            string[,] next_key = new string[4, 4];
            int c = 2;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {

                    next_key[j, i] = key[c].ToString() + key[c + 1].ToString();
                    c += 2;
                }
            }


            string[] holder = new string[4];
            for (int i = 0; i < 4; i++)
                holder[i] = next_key[i, 3];

            string temper_after_inverse = "";
            string[] inverse = new string[4];
            inverse[0] = holder[1];
            inverse[1] = holder[2];
            inverse[2] = holder[3];
            inverse[3] = holder[0];

            for (int i = 0; i < 4; i++)
                temper_after_inverse += inverse[i];

            string newtemp = "";

            temper_after_inverse = temper_after_inverse.ToUpper();


            for (int i = 0; i < temper_after_inverse.Length; i += 2)
            {
                int first_one = temper_after_inverse[i] - '0';
                if (first_one > 15) first_one -= 7;
                int second_one = temper_after_inverse[i + 1] - '0';
                if (second_one > 15) second_one -= 7;
                newtemp += S_box[first_one, second_one];
            }

            string[,] the_new_key = new string[4, 4];

            int lafa = 0;
            for (int i = 0; i < 4; i++)
            {
                int the_second = Convert.ToInt32(newtemp.Substring(lafa, 2), 16);
                int the_key = Convert.ToInt32(next_key[i, 0], 16);
                int r_con_value = Convert.ToInt32(R_con[i, round], 16);
                int oring_value = the_key ^ the_second ^ r_con_value;
                string converter = Convert.ToString(oring_value, 16);
                if (oring_value < 16)
                    the_new_key[i, 0] = "0" + converter;
                else
                    the_new_key[i, 0] = converter;
                lafa = lafa + 2;
            }

            for (int i = 1; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    int secc = Convert.ToInt32(the_new_key[j, i - 1], 16);
                    int keyy = Convert.ToInt32(next_key[j, i], 16);
                    int oring_value = keyy ^ secc;
                    string hes = Convert.ToString(oring_value, 16);
                    if (oring_value < 16)
                        the_new_key[j, i] = "0" + hes;
                    else
                        the_new_key[j, i] = hes;
                }
            }
            string Result_Key = "0x";
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    Result_Key += the_new_key[j, i];

            return Result_Key;
            //		Result_Key	"0xa0fafe1788542cb123a339392a6c7605"	string

        }
        public static string AddroundKey(string[,] requestet_plan, string key)
        {

            string rounder_for_plain = "";
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    rounder_for_plain += requestet_plan[i, j];
                }
            }
            //plain1d = "3243F6A8885A308D313198A2e0370734";

            //round by convert to integer and xoring between them then return them to string again

            if (rounder_for_plain[1] == 'x' || rounder_for_plain[1] == 'X') rounder_for_plain = rounder_for_plain.Substring(2, 32);
            string returner = "";
            for (int i = 0; i < rounder_for_plain.Length; i += 2)
            {
                int num_for_key = Convert.ToInt32(key.Substring(i + 2, 2), 16);
                int rounder_plain = Convert.ToInt32(rounder_for_plain.Substring(i, 2), 16);
                int result_of_rounder = rounder_plain ^ num_for_key;
                string looper = "";
                if (result_of_rounder < 16)
                    looper = "0" + Convert.ToString(result_of_rounder, 16);
                else
                    looper = Convert.ToString(result_of_rounder, 16);
                returner += looper;
            }
            return returner;
        }
        static byte[,] sboxInverse = new byte[16, 16] { { 0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb },
                                                        { 0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb },
                                                        { 0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e },
                                                        { 0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25 },
                                                        { 0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92 },
                                                        { 0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84 },
                                                        { 0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06 },
                                                        { 0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b },
                                                        { 0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73 },
                                                        { 0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e },
                                                        { 0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b },
                                                        { 0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4 },
                                                        { 0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f },
                                                        { 0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef },
                                                        { 0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61 },
                                                        { 0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d } };
        /// <summary>
        /// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        byte[,] galoisFieldInverse = new byte[4, 4] {   {0x0e, 0x0b, 0x0d, 0x09},
                                                        {0x09, 0x0e, 0x0b, 0x0d},
                                                        {0x0d, 0x09, 0x0e, 0x0b},
                                                        {0x0b, 0x0d, 0x09, 0x0e}};
        /// <summary>
        /// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        byte[,] sbox = new byte[16, 16] {   {0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76},
                                            {0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0},
                                            {0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15},
                                            {0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75},
                                            {0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84},
                                            {0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF},
                                            {0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8},
                                            {0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2},
                                            {0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73},
                                            {0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB},
                                            {0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79},
                                            {0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08},
                                            {0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A},
                                            {0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E},
                                            {0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF},
                                            {0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16} };
        /// <summary>
        /// ///////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        int Rcon_index = 0;
        public static byte[,] Rcon_de = new byte[4, 10] { {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36 },
                                         {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
                                         {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
                                         {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }};
        /// <summary>
        /// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>

        byte[,] key_expansion = new byte[44, 4];
        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="y"></param>
        /// <returns></returns>
        byte advancedmultiplybyTwo(byte y)
        {
            byte r;
            UInt32 temp = Convert.ToUInt32(y << 1);
            r = (byte)(temp & 0xFF);
            if (y > 127)
                r = Convert.ToByte(r ^ 27);
            return r;
        }
        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="shmatrix"></param>
        /// <returns></returns>
        byte[,] mixColsInverse(byte[,] shmatrix)
        {
            List<byte> mixMat = new List<byte>();
            byte[] arrXor = new byte[4];
            byte[,] mixColMat = new byte[4, 4];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    for (int k = 0; k < 4; k++)
                    {
                        if (galoisFieldInverse[j, k] == 0x9)
                        {
                            byte x = shmatrix[k, i];
                            byte z = advancedmultiplybyTwo(x);
                            byte y = advancedmultiplybyTwo(z);
                            byte f = advancedmultiplybyTwo(y);
                            arrXor[k] = Convert.ToByte(f ^ x);
                        }
                        if (galoisFieldInverse[j, k] == 0xB)
                        {
                            byte x = shmatrix[k, i];
                            byte y = advancedmultiplybyTwo(x);
                            byte z = advancedmultiplybyTwo(y);
                            byte f = advancedmultiplybyTwo(z);
                            arrXor[k] = Convert.ToByte(f ^ x ^ y);

                        }
                        if (galoisFieldInverse[j, k] == 0xD)
                        {
                            byte x = shmatrix[k, i];
                            byte y = advancedmultiplybyTwo(x);
                            byte z = advancedmultiplybyTwo(y);
                            byte f = advancedmultiplybyTwo(z);
                            arrXor[k] = Convert.ToByte(f ^ z ^ x);

                        }

                        if (galoisFieldInverse[j, k] == 0xE)
                        {
                            byte x = shmatrix[k, i];
                            byte y = advancedmultiplybyTwo(x);
                            byte z = advancedmultiplybyTwo(y);
                            byte f = advancedmultiplybyTwo(z);
                            arrXor[k] = Convert.ToByte(f ^ z ^ y);

                        }
                    }
                    var cell = arrXor[0] ^ arrXor[1] ^ arrXor[2] ^ arrXor[3];
                    mixColMat[j, i] = Convert.ToByte(cell);

                }
            }
            return mixColMat;
        }
        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        byte[,] makeByteMatrix(string s)
        {
            byte[,] m = new byte[4, 4];

            int k;
            k = 2;
            for (int j = 0; j <= 3; j++)
            {
                for (int i = 0; i <= 3; i++)
                {
                    string tmp = "0x" + s[k] + s[k + 1];
                    m[i, j] = Convert.ToByte(tmp, 16);
                    k += 2;
                }
            }
            return m;
        }
        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        byte[,] makeByteMatrix2(string s)
        {
            byte[,] m = new byte[4, 4];

            int k;
            k = 2;
            for (int j = 0; j <= 3; j++)
            {
                for (int i = 0; i <= 3; i++)
                {
                    string tmp = "0x" + s[k] + s[k + 1];
                    m[j, i] = Convert.ToByte(tmp, 16);
                    k += 2;
                }
            }
            return m;
        }
        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="k"></param>
        void put_key(string k)
        {
            byte[,] key_arr = new byte[4, 4];
            key_arr = makeByteMatrix2(k);
            for (int i = 0; i <= 3; i++)
                for (int j = 0; j <= 3; j++)
                    key_expansion[i, j] = key_arr[i, j];

        }
        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        byte[,] get_key_matrix(int index)
        {
            byte[,] mat = new byte[4, 4];
            int r = 0;
            int c = 0;
            for (int i = index * 4; i < index * 4 + 4; i++)
            {
                c = 0;
                for (int j = 0; j < 4; j++)
                {
                    mat[c, r] = key_expansion[i, j];
                    c += 1;
                }
                r = r + 1;
            }
            return mat;
        }
        /// <summary>
        /// ///////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="w"></param>
        /// <returns></returns>
        byte[] Rotword(byte[] w)
        {
            byte first = w[0];
            for (int i = 0; i <= 2; i++)
                w[i] = w[i + 1];
            w[3] = first;
            return w;
        }
        /// <summary>
        /// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="w"></param>
        /// <returns></returns>
        byte[] Sub_Byte(byte[] w)
        {
            byte[] r = new byte[4];
            int nI;
            int nJ;
            for (int i = 0; i <= 3; i++)
            {
                string tmp = Convert.ToString(w[i], 16);
                if (tmp.Length == 1)
                {
                    nI = 0;
                    nJ = Convert.ToInt32(tmp[0].ToString(), 16);
                }
                else
                {
                    nI = Convert.ToInt32(tmp[0].ToString(), 16);
                    nJ = Convert.ToInt32(tmp[1].ToString(), 16);
                }
                r[i] = sbox[nI, nJ];
                //
            }
            return r;
        }//
        /// <summary>
        /// /////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="f"></param>
        /// <param name="s"></param>
        /// <param name="third"></param>
        /// <param name="mult_oF_4"></param>
        /// <returns></returns>
        byte[] xor(byte[] f, byte[] s, byte[] third, int mult_oF_4)
        {
            byte[] r = new byte[4];
            for (int i = 0; i <= 3; i++)
            {
                string tmp;
                //
                if (mult_oF_4 == 0)
                    tmp = Convert.ToString(f[i] ^ s[i], 16);
                //
                else
                    tmp = Convert.ToString(f[i] ^ s[i] ^ third[i], 16);

                r[i] = Convert.ToByte(tmp, 16);

            }


            return r;
        }
        /// <summary>
        /// ///////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        void implement_key_expansion()
        {
            byte[] f = new byte[4];
            byte[] scd = new byte[4];
            byte[] thd = new byte[4];
            byte[] final = new byte[4];
            for (int i = 4; i < 44; i++)
            {
                for (int j = 0; j <= 3; j++)
                {
                    f[j] = key_expansion[i - 1, j];
                    scd[j] = key_expansion[i - 4, j];
                    if (Rcon_index < 10)
                        thd[j] = Rcon_de[j, Rcon_index];
                }
                if (i % 4 == 0)
                {
                    Rcon_index++;
                    f = Rotword(f);
                    f = Sub_Byte(f);
                    final = xor(f, scd, thd, 1);
                }
                else
                    final = xor(f, scd, thd, 0);

                for (int j = 0; j < 4; j++)
                {
                    key_expansion[i, j] = final[j];
                }

            }
        }
        /// <summary>
        /// ///////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="matrix"></param>
        /// <param name="Round_index"></param>
        /// <returns></returns>
        byte[,] RoundKey(byte[,] m, int R_index)
        {
            byte[,] key_round;
            key_round = get_key_matrix(R_index);

            // 

            //

            string tmp;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    tmp = Convert.ToString(key_round[i, j] ^ m[i, j], 16);
                    key_round[i, j] = Convert.ToByte(tmp, 16);
                }
            }
            return key_round;
        }
        /// <summary>
        /// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="matrix"></param>
        /// <returns></returns>
        byte[,] substituteMatrixInverse(byte[,] m)
        {
            byte[,] nM = new byte[4, 4];
            for (int i = 0; i <= 3; i++)
            {
                for (int j = 0; j <= 3; j++)
                {
                    string tmp;
                    tmp = Convert.ToString(m[i, j], 16);
                    int nI;
                    int nJ;
                    if (tmp.Length == 1)
                    {
                        nI = 0;
                        nJ = Convert.ToInt32(tmp[0].ToString(), 16);
                    }
                    else
                    {
                        nI = Convert.ToInt32(tmp[0].ToString(), 16);
                        nJ = Convert.ToInt32(tmp[1].ToString(), 16);
                    }


                    nM[i, j] = sboxInverse[nI, nJ];
                }
            }
            return nM;
        }
        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="r"></param>
        /// <param name="num"></param>
        /// <returns></returns>
        byte[] shiftRowInverse(byte[] r, int num)
        {
            UInt32 n = 0;
            for (int i = 0; i <= 3; i++)
            {

                n += Convert.ToUInt32(r[i]);
                if (i != 3) n = n << 8;
            }
            n = ((n >> (num * 8)) | (n) << (32 - (num * 8)));

            byte[] nRow = new byte[4];
            for (int i = 3; i >= 0; i--)
            {
                nRow[i] = (byte)(n & 0xFF);
                n = n >> 8;
            }
            return nRow;
        }
        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="m"></param>
        /// <returns></returns>
        byte[,] shiftMatrixInverse(byte[,] m)
        {
            byte[,] nMatrix = new byte[4, 4];
            byte[] r = new byte[4];
            for (int i = 0; i < 4; i++)
            {
                for (int j1 = 0; j1 < 4; j1++)
                {
                    r[j1] = m[i, j1];
                }
                r = shiftRowInverse(r, i);
                for (int j2 = 0; j2 < 4; j2++)
                {
                    nMatrix[i, j2] = r[j2];
                }
            }
            return nMatrix;
        }
        /// <summary>
        /// /////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        byte[,] finalRoundDecrypt(byte[,] s)
        {
            s = RoundKey(s, 10);
            s = shiftMatrixInverse(s);
            s = substituteMatrixInverse(s);
            return s;
        }
        /// <summary>
        /// //////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="s"></param>
        /// <param name="r"></param>
        /// <returns></returns>
        byte[,] main_rounds_decryption(byte[,] s, int r)
        {
            s = RoundKey(s, r);

            s = mixColsInverse(s);

            s = shiftMatrixInverse(s);

            s = substituteMatrixInverse(s);
            // 
            return s;
        }
        /// <summary>
        /// /////////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        byte[,] firstRoundDecryption(byte[,] s)
        {
            s = RoundKey(s, 0);
            return s;
        }
        /// <summary>
        /// ////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="m"></param>
        /// <returns></returns>
        string makeMatrixString(byte[,] m)
        {
            StringBuilder s = new StringBuilder();
            for (int i = 0; i <= 3; i++)
            {
                for (int j = 0; j <= 3; j++)
                {
                    // var tmp;
                    var tmp = Convert.ToString(m[j, i], 16);
                    if (tmp.Length <= 1)
                    {
                        s.Append("0" + tmp);
                    }
                    else s.Append(tmp);
                }
            }
            return s.ToString().ToUpper().Insert(0, "0x");
        }
        /// <summary>
        /// /////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <param name="cipherText"></param>
        /// <param name="key"></param>
        /// <returns></returns>

        public override string Decrypt(string cipherText, string key)
        {
            byte[,] s = makeByteMatrix(cipherText);
            string k;
            k = key;
            put_key(k);
            implement_key_expansion();
            s = finalRoundDecrypt(s);
            int i = 9;
            while (i > 0)
            {

                s = main_rounds_decryption(s, i);
                i = i - 1;
            }

            s = firstRoundDecryption(s);
            k = makeMatrixString(s);
            return k;
        }

        public override string Encrypt(string plainText, string key)
        {
            string[,] plain1 = new string[4, 4];
            if (plainText[1] == 'x' || plainText[1] == 'X') plainText = plainText.Substring(2, 32);
            for (int h = 0, k = 0; h < 4; h++)
            {
                for (int j = 0; j < 4; j++, k += 2)
                {
                    string ss = plainText[k].ToString() + plainText[k + 1];
                    plain1[h, j] = ss;
                }
            }
            plainText = AddroundKey(plain1, key);

            for (int i = 0; i < 9; i++)
            {

                plainText = get_sub_bytes_string(plainText);
                plainText = matrix_transpose(plainText);
                plainText = shift_rows(plainText);
                plainText = matrix_transpose(plainText);
                plainText = mix_cols(plainText);
                if (plainText[1] == 'x' || plainText[1] == 'X') plainText = plainText.Substring(2, 32);
                key = KeyExpansion(key, i);
                for (int h = 0, k = 0; h < 4; h++)
                {
                    for (int j = 0; j < 4; j++, k += 2)
                    {
                        string ss = plainText[k].ToString() + plainText[k + 1];
                        plain1[h, j] = ss;
                    }
                }
                plainText = AddroundKey(plain1, key);
            }
            plainText = get_sub_bytes_string(plainText);
            plainText = matrix_transpose(plainText);
            plainText = shift_rows(plainText);
            plainText = matrix_transpose(plainText);
            key = KeyExpansion(key, 9);
            for (int i = 0, k = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++, k += 2)
                {
                    string ss = plainText[k].ToString() + plainText[k + 1];
                    plain1[i, j] = ss;
                }
            }
            plainText = AddroundKey(plain1, key);
            return "0x" + plainText;


        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SecurityLibrary
{

    public class Ceaser : ICryptographicTechnique<string, int>
    {

        public string Encrypt(string plainText, int key)
        {
            char[] CipherChars = new char[plainText.Length];
            int CipherNumber = 0;
            plainText = plainText.ToUpper();
            for (int i = 0; i < plainText.Length; i++)
            {
                CipherNumber = ((int)(plainText[i]) - 65 + key) % 26;
                CipherChars[i] = (char)(CipherNumber + 65);

            }
            string CipherText = new string(CipherChars);

            return CipherText;
        }

        public string Decrypt(string cipherText, int key)
        {
            return Encrypt(cipherText, 26 - key);
        }

        public int Analyse(string plainText, string cipherText)
        {
            int ciphernum = 0;
            int plainnum = 0;
            int key = 0;
            cipherText = cipherText.ToUpper();
            ciphernum = (int)cipherText[0];
            plainText = plainText.ToUpper();
            plainnum = (int)plainText[0];
            key = ciphernum - plainnum;
            if (key < 0)
                key = key + 26;
            return key;
        }

        
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class Monoalphabetic : ICryptographicTechnique<string, string>
    {
       
        public string Analyse(string plainText, string cipherText)
        {
            string alpha = "abcdefghijklmnopqrstuvwxyz";
            cipherText = cipherText.ToLower();
            char[] chars = new char[26];
            for (int i = 0; i < plainText.Length; i++)
            {
                chars[alpha.IndexOf(plainText[i])] = cipherText[i];
            }
            for (int i = 0; i < 26; i++)
            {
                if (chars[i] == default(char))
                {
                    int j;
                    for (j = 0; j < 26; j++)
                    {
                        if (!chars.Contains(alpha[j]))
                            break;
                    }
                    chars[i] = alpha[j];
                }
            }
            string key = new string(chars);
            return key;
        }


        public string Decrypt(string cipherText, string key)
        {
            string plainText = "";
            cipherText = cipherText.ToLower();

            for (int i = 0; i < cipherText.Length; i++)
            {
                int index = key.IndexOf(cipherText[i]);

                char decryptedChar = (char)('A' + index);
                plainText += decryptedChar;
            }

            return plainText.ToLower();
        }

        public string Encrypt(string plainText, string key)
        {
            string cipherText = "";
            plainText = plainText.ToUpper();

            foreach (char ch in plainText)
            {
                char start = 'A';
                int index = ch - start;
                char encryptedChar = (key[index]);
                cipherText += encryptedChar;
            }

            return cipherText;
        }






        /// <summary>
        /// Frequency Information:
        /// E   12.51%
        /// T	9.25
        /// A	=
        /// O	7.60
        /// I	7.26
        /// N	7.09
        /// S	6.54
        /// R	6.12
        /// H	5.49
        /// L	4.14
        /// D	3.99
        /// C	3.06
        /// U	2.71
        /// M	2.53
        /// F	2.30
        /// P	2.00
        /// G	1.96
        /// W	1.92
        /// Y	1.73
        /// B	1.54
        /// V	0.99
        /// K	0.67
        /// X	0.19
        /// J	0.16
        /// Q	0.11
        /// Z	0.09
        /// </summary>
        /// <param name="cipher"></param>
        /// <returns>Plain text</returns>
        /// 

        public string AnalyseUsingCharFrequency(string cipher)
        {

            cipher = cipher.ToLower();
            string lettersInOrder = "etaoinsrhldcumfpgwybvkxjqz";
            Dictionary<char, int> frequencyTable = new Dictionary<char, int>();
            
            // Build frequency table using cipher text
            foreach (char c in cipher)
            {
                if (!frequencyTable.ContainsKey(c))
                {
                    frequencyTable[c] = GetLetterFrequency(cipher, c);
                }
            }

            // Order by most frequent first to match the lettersInOrder string mapping.
            frequencyTable = frequencyTable.OrderByDescending(pair => pair.Value).ToDictionary(pair => pair.Key, pair => pair.Value);
            string cipherOrdered = "";

            foreach (KeyValuePair<char, int> p in frequencyTable) {
                cipherOrdered += p.Key;
            }

            // Get the key by comparing similar frequencies together.
            string key = "";
            for (int i = 0; i < 26; i++)
            {
                int letterIndex = lettersInOrder.IndexOf(Convert.ToChar('a' + i));
                key += cipherOrdered[letterIndex];
            }
            
            // Decrypt using the extracted key
            return Decrypt(cipher, key);

        }

        // Gets the number of occurences of one letter in a word.
        public int GetLetterFrequency(string word, char letter)
        {
            int count = 0;
            foreach (char c in word)
            {
                if (c == letter)
                {
                    count++;   
                }
            }
            return count;
        
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class RepeatingkeyVigenere : ICryptographicTechnique<string, string>
    {


        string alphabet = "abcdefghijklmnopqrstuvwxyz";

        public string Analyse(string plainText, string cipherText)
        {
            cipherText = cipherText.ToLower();
            plainText = plainText.ToLower();

            Dictionary<char, int> AlphabetToNum = new Dictionary<char, int>();
            Dictionary<int, char> rankingAlphabet = new Dictionary<int, char>();

            for (int i = 0; i < alphabet.Length; i++)
            {
                AlphabetToNum[alphabet[i]] = i;
                rankingAlphabet[i] = alphabet[i];
            }

            char[] analysedKey = new char[cipherText.Length];

            int index = 0;
            for (int i = 0; i < cipherText.Length; i++)
            {
                int counter = AlphabetToNum[plainText[i]];

                for (int j = 0; j < alphabet.Length; j++)
                {
                    if (alphabet[counter % 26] != cipherText[i])
                        counter++;
                    else
                    {
                        index = j;
                        break;
                    }
                }

                analysedKey[i] = rankingAlphabet[index];
            }

            int finalKeyIndex = 0;
            string allKey = new string(analysedKey);
            string originalKey = allKey.Substring(0, 3);

            for (int i = 3; i < allKey.Length; i++)
            {
                originalKey += allKey[i];
                int subStringIndex = allKey.IndexOf(originalKey, i);

                if (subStringIndex > i)
                {
                    if (finalKeyIndex == subStringIndex)
                        break;
                    else
                        finalKeyIndex = subStringIndex;
                }
            }

            return allKey.Substring(0, finalKeyIndex);
        }

        public string Decrypt(string cipherText, string key)
        {
            cipherText = cipherText.ToLower();
            int size = cipherText.Length - key.Length;

            Dictionary<char, int> AlphabetToNum = new Dictionary<char, int>();
            Dictionary<int, char> rankingAlphabet = new Dictionary<int, char>();

            for (int i = 0; i < alphabet.Length; i++)
            {
                AlphabetToNum[alphabet[i]] = i;
                rankingAlphabet[i] = alphabet[i];
            }

            if (key.Length < cipherText.Length)
            {
                for (int i = 0; i < size; i++)
                    key += key[i];
            }

            char[] decryptedText = new char[cipherText.Length];

            int index = 0;
            for (int i = 0; i < cipherText.Length; i++)
            {
                int counter = AlphabetToNum[key[i]];
                for (int j = 0; j < alphabet.Length; j++)
                {
                    if (alphabet[counter % 26] != cipherText[i])
                        counter++;
                    else
                    {
                        index = j;
                        break;
                    }
                }
                decryptedText[i] = rankingAlphabet[index];
            }

            return new string(decryptedText);
        }

        public string Encrypt(string plainText, string key)
        {
            plainText = plainText.ToLower();
            int size = plainText.Length - key.Length;

            Dictionary<char, int> AlphabetToNum = new Dictionary<char, int>();
            Dictionary<int, char> rankingAlphabet = new Dictionary<int, char>();

            for (int i = 0; i < alphabet.Length; i++)
            {
                AlphabetToNum[alphabet[i]] = i;
                rankingAlphabet[i] = alphabet[i];
            }

            if (key.Length < plainText.Length)
            {
                for (int i = 0; i < size; i++)
                {
                    key += key[i];
                }
            }

            char[] encryptedText = new char[plainText.Length];
            int index = 0;
            for (int i = 0; i < plainText.Length; i++)
            {
                index = (AlphabetToNum[plainText[i]] + AlphabetToNum[key[i]]) % 26;
                encryptedText[i] = rankingAlphabet[index];
            }

            return new string(encryptedText).ToUpper();
        }
    }
}

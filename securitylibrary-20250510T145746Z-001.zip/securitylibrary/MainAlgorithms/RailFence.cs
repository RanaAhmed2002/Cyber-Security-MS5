﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{
    public class RailFence : ICryptographicTechnique<string, int>
    {
        public int Analyse(string plainText, string cipherText)
        {
            int key = 0;
            int i = 2;
            while (i < plainText.Length - 1)
            {
                string encrypted_text = Encrypt(plainText, i);
                StringBuilder cipherText2 = new StringBuilder();

                int j = 0; while (j < encrypted_text.Length)
                {
                    if ((encrypted_text[j] >= 'A') && (encrypted_text[j] <= 'Z'))
                    { cipherText2.Append(encrypted_text[j]); }
                    j++;
                }

                string ciphertext = cipherText2.ToString(); if (cipherText == ciphertext)
                {
                    key = i;
                    break;
                }

                i++;
            }
            return key;

        }

        public string Decrypt(string cipherText, int key)
        {
            string PT = "";
            int rows = key;
            int columns = (int)Math.Ceiling((double)cipherText.Length / (double)key);
            char[,] temp = new char[rows, columns];
            int counter = 0;

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    if (counter == cipherText.Length)
                    {
                        break;
                    }
                    temp[i, j] = cipherText[counter];
                    counter++;
                }
            }

            for (int i = 0; i < columns; i++)
            {
                for (int j = 0; j < rows; j++)
                {
                    PT += temp[j, i];
                }
            }

            return PT.ToUpper();
        }

        public string Encrypt(string plainText, int key)
        {

            string CT = "";

            for (int i = 0; i < key; i++)
            {
                for (int j = i; j < plainText.Length; j += key)
                {
                    CT += plainText[j];
                }
            }

            return CT.ToUpper();
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityLibrary
{

    public class HillCipher : ICryptographicTechnique<string, string>, ICryptographicTechnique<List<int>, List<int>>
    {
        public static int calcsqrt(List<int> key)
        {
            int keyCount = key.Count;
            int keySize;
            for (int i = 0; i < key.Count; i++)
            {
                if (keyCount == i * i)
                {
                    keySize = i;
                    return keySize;
                }
            }
            throw new InvalidAnlysisException();
        }

        public static int CalculateDeterminant(List<int> matrix)
        {
            int size = calcsqrt(matrix);
            if (matrix.Count != size * size)
            {
                throw new ArgumentException("Matrix should be square.");
            }

            // Base case for 2x2 matrix
            if (size == 2)
            {
                int det = ((matrix[0] * matrix[3]) - (matrix[1] * matrix[2]));
                det = det % 26;

                if (det > 0)
                    return det;
                else if (det == 0)
                    throw new InvalidAnlysisException();
                else
                    return det + 26;
            }

            int determinant = 0;
            int sign = 1;

            for (int i = 0; i < size; i++)
            {
                List<int> subMatrix = GetSubMatrix(matrix, 0, i, size);
                determinant += sign * matrix[i] * CalculateDeterminant(subMatrix);
                sign = -sign;
            }
            determinant = determinant % 26;

            if (determinant > 0)
                return determinant;
            else
                return determinant + 26;
        }

        private static List<int> GetSubMatrix(List<int> matrix, int excludeRow, int excludeColumn, int size)
        {
            List<int> subMatrix = new List<int>();

            for (int i = 0; i < size; i++)
            {
                if (i == excludeRow)
                {
                    continue;
                }

                for (int j = 0; j < size; j++)
                {
                    if (j == excludeColumn)
                    {
                        continue;
                    }

                    subMatrix.Add(matrix[i * size + j]);
                }
            }

            return subMatrix;
        }

        public static int CalculateModularInverse(int determinant)
        {
            for (int i = 1; i < 26; i++)
            {
                if ((determinant * i) % 26 == 1)
                {
                    return i;
                }
            }

            throw new InvalidAnlysisException();
        }

        static List<int> CalculateCoff(List<int> adjugate, int detInverse)
        {
            List<int> result = new List<int>();
            int size = calcsqrt(adjugate);
            if (size == 2)
            {
                int a = (detInverse * adjugate[3] < 0 ? (detInverse * adjugate[3]) % 26 + 26 : detInverse * adjugate[3] % 26);
                result.Add(a);
                int b = (detInverse * adjugate[1] * (-1) < 0 ? (detInverse * adjugate[1] * (-1)) % 26 + 26 : detInverse * adjugate[1] * (-1) % 26);
                result.Add(b);
                int c = (detInverse * adjugate[2] * (-1) < 0 ? (detInverse * adjugate[2] * (-1)) % 26 + 26 : detInverse * adjugate[2] * (-1) % 26);
                result.Add(c);
                int d = (detInverse * adjugate[0] < 0 ? (detInverse * adjugate[0]) % 26 + 26 : detInverse * adjugate[0] % 26);
                result.Add(d);
                return result;
            }
            else
            {
                for (int i = 0; i < adjugate.Count; i++)
                {
                    int row = i / size;
                    int value = 0;
                    int col = i % size;
                    int power = (row + col) % 2 == 0 ? 1 : -1;

                    {
                        List<int> subMatrix = GetSubMatrix(adjugate, row, col, size);
                        value = (detInverse * power * ((subMatrix[0] * subMatrix[3]) - (subMatrix[1] * subMatrix[2]))) % 26;
                    }

                    if (value < 0)
                    {
                        value += 26;
                    }
                    result.Add(value);
                }
            }

            return result;
        }

        static List<int> TransposeMatrix(List<int> matrix)
        {
            int size = calcsqrt(matrix);
            List<int> result = new List<int>(matrix.Count);

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    result.Add(matrix[j * size + i]);
                }
            }

            return result;
        }



        // Solve two linear equations in two unknowns each, by trying all combinations of the two variables (26^2), this is done 2 times, once for each row
        public List<int> Analyse(List<int> plainText, List<int> cipherText)
        {

            int[] key = new int[4] { 0, 0, 0, 0 };

            // Get the first row for the key
            for (int i = 0; i < 26; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    if ((i * plainText[0] + j * plainText[1]) % 26 == cipherText[0] && (i * plainText[2] + j * plainText[3]) % 26 == cipherText[2])
                    {
                        key[0] = i;
                        key[1] = j;
                        break;
                    }
                }
            }

            // Get the second row for the key
            for (int i = 0; i < 26; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    if ((i * plainText[0] + j * plainText[1]) % 26 == cipherText[1] && (i * plainText[2] + j * plainText[3]) % 26 == cipherText[3])
                    {
                        key[2] = i;
                        key[3] = j;
                        break;
                    }
                }
            }

            // Invalid key (determinant = 0)
            if (key[0] * key[3] - key[2] * key[1] == 0) throw new InvalidAnlysisException();

            return key.ToList();

        }
        public string Analyse(string plainText, string cipherText)
        {
            throw new NotImplementedException();
        }

        public List<int> Decrypt(List<int> cipherText, List<int> key)
        {
            List<int> plaintext;

            int determinant = CalculateDeterminant(key);

            int detInverse = CalculateModularInverse(determinant);

            List<int> adjugate = CalculateCoff(key, detInverse);

            if (key.Count > 4)
            {
                List<int> inverseKey = TransposeMatrix(adjugate);
                plaintext = Encrypt(cipherText, inverseKey);
            }
            else
                plaintext = Encrypt(cipherText, adjugate);

            return plaintext;
        }


        public string Decrypt(string cipherText, string key)
        {
            throw new NotImplementedException();
        }


        public List<int> Encrypt(List<int> plainText, List<int> key)
        {
            int keySize = calcsqrt(key);
            int textSize = plainText.Count;

            List<int> cipherText = new List<int>();
            for (int i = 0; i < textSize; i += keySize)
            {
                List<int> block = plainText.GetRange(i, keySize);

                for (int j = 0; j < keySize; j++)
                {
                    int sum = 0;
                    for (int k = 0; k < keySize; k++)
                    {
                        sum += block[k] * key[j * keySize + k];
                    }
                    cipherText.Add(sum % 26);
                }
            }

            return cipherText;
        }

        public string Encrypt(string plainText, string key)
        {
            throw new NotImplementedException();
        }


        // Solve three linear equations in three unknowns each, by trying all combinations of the three variables (26^3), this is done 3 times, once for each row
        public List<int> Analyse3By3Key(List<int> plain3, List<int> cipher3)
        {
            int[] key = new int[9];

            // Get the first row for the key
            for (int i = 0; i < 26; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    for (int k = 0; k < 26; k++)
                    {
                        if ((i * plain3[0] + j * plain3[1] + k * plain3[2]) % 26 == cipher3[0] && (i * plain3[3] + j * plain3[4] + k * plain3[5]) % 26 == cipher3[3] && (i * plain3[6] + j * plain3[7] + k * plain3[8]) % 26 == cipher3[6])
                        {
                            key[0] = i;
                            key[1] = j;
                            key[2] = k;
                            break;
                        }
                    }

                }
            }

            // Get the second row for the key
            for (int i = 0; i < 26; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    for (int k = 0; k < 26; k++)
                    {
                        if ((i * plain3[0] + j * plain3[1] + k * plain3[2]) % 26 == cipher3[1] && (i * plain3[3] + j * plain3[4] + k * plain3[5]) % 26 == cipher3[4] && (i * plain3[6] + j * plain3[7] + k * plain3[8]) % 26 == cipher3[7])
                        {
                            key[3] = i;
                            key[4] = j;
                            key[5] = k;
                            break;
                        }
                    }

                }
            }

            // Get the third row for the key
            for (int i = 0; i < 26; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    for (int k = 0; k < 26; k++)
                    {
                        if ((i * plain3[0] + j * plain3[1] + k * plain3[2]) % 26 == cipher3[2] && (i * plain3[3] + j * plain3[4] + k * plain3[5]) % 26 == cipher3[5] && (i * plain3[6] + j * plain3[7] + k * plain3[8]) % 26 == cipher3[8])
                        {
                            key[6] = i;
                            key[7] = j;
                            key[8] = k;
                            break;
                        }
                    }

                }
            }

            return key.ToList();
        }


        public string Analyse3By3Key(string plain3, string cipher3)
        {
            throw new NotImplementedException();
        }



    }
}

